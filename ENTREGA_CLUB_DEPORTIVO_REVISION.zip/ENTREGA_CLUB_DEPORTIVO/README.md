# CLUB DEPORTIVO - Paquete de preparación para entrega

Aplicación de escritorio C# Windows Forms para Visual Studio 2022, .NET 8 y MySQL.

## Estado honesto del paquete

Se actualizaron el ingreso de parámetros de conexión por teclado, las clases de dominio para mostrar los cuatro pilares de POO, el uso del procedimiento almacenado de vencimientos y la organización documental. **Este paquete todavía NO puede considerarse listo para entregar**: en este entorno no está instalado .NET/Visual Studio ni MySQL, por lo que no se pudo compilar, ejecutar ni generar el `ClubDeportivo.exe`. Tampoco se pueden inventar capturas de una aplicación que aún no se ejecutó ni un video de coloquio que debe realizar el equipo.

## Requisitos
- Windows 10/11.
- Visual Studio 2022 actualizado con la carga de trabajo “Desarrollo de escritorio de .NET”.
- .NET 8 SDK.
- MySQL Server 8 y MySQL Workbench.

## Instalación y prueba
1. Abrir `club_deportivo.sql` (también está dentro de `DB`) en MySQL Workbench y ejecutarlo.
2. Abrir `Código/CLUB_DEPORTIVO.sln` con Visual Studio 2022.
3. Dejar la configuración **Debug** para ejecutar desde Visual Studio.
4. Ejecutar con F5. Al iniciar aparece la pantalla de conexión; ingresar servidor, puerto, base de datos, usuario y contraseña por teclado. El botón prueba la conexión antes de continuar.
5. Iniciar sesión: usuario `admin`, contraseña `Club2026!`.
6. Probar los casos del documento `Documentación/Documentacion_del_sistema.pdf` y completar la evidencia real en `Capturas/Evidencias_para_completar.pdf`.

## Crear el ejecutable (Fase 7)
1. En Visual Studio seleccionar `Release` en la barra de configuración o Administrador de configuración.
2. Usar Compilar > Limpiar solución y luego Compilar > Recompilar solución.
3. Ubicar la carpeta `bin/Release/net8.0-windows/` del proyecto. Copiar **todo su contenido** dentro de `Ejecutable/Release/`, no solamente el `.exe`.
4. Verificar que `ClubDeportivo.exe` esté presente y ejecutar desde esa carpeta.
5. Probar la carpeta Release en otra PC con MySQL instalado y la base creada.
6. Volver a seleccionar `Debug` para continuar trabajando en Visual Studio.

## Reglas funcionales implementadas en esta versión
- DNI/documento único mediante restricción UNIQUE en la base de datos.
- Alta de socio y no socio; el alta exige apto físico vigente y ficha completa.
- Para socio se registra la fila de socio y se genera su carnet dentro de una transacción.
- Pago diario vence el mismo día.
- Pago mensual: si ya existe un pago mensual anterior, el nuevo período comienza el día siguiente al vencimiento anterior; si no existe, comienza el día del pago. El vencimiento se calcula a un mes menos un día desde el inicio. Esta interpretación debe validarse con el criterio de la cátedra/cliente si el caso concreto requiere otra regla.
- El procedimiento `sp_vencimientos(7)` devuelve socios cuya última cuota está vencida, vence hoy o vence dentro de los próximos siete días.

## Seguridad
El usuario inicial de demostración es `admin` / `Club2026!`. Cambiarlo antes de un uso real; la aplicación de esta versión aún no incluye una pantalla para cambiar contraseña. No publicar credenciales de MySQL.

## Pendientes obligatorios antes de enviar
- Compilar y resolver cualquier error en Windows/Visual Studio 2022.
- Ejecutar pruebas reales con MySQL y completar el PDF de capturas con evidencias auténticas.
- Generar y probar el ejecutable Release en otra PC.
- Incorporar el video/link del coloquio con permisos de visualización.
- Completar comisión, grupo, apellidos e integrantes en el nombre del ZIP y en la carátula.
- Confirmar con el equipo/docente la regla de vencimiento mensual y los importes de ejemplo ($15.000 y $2.000), que son valores iniciales de demostración, no provistos por el enunciado.
