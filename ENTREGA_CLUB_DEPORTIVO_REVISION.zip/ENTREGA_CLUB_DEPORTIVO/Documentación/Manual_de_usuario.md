# Manual de usuario — Club Deportivo

## 1. Preparación
Instalar MySQL Server 8 y ejecutar `club_deportivo.sql` desde MySQL Workbench. Abrir `CLUB_DEPORTIVO.sln` en Visual Studio 2022 con .NET 8.

## 2. Configurar conexión
Al iniciar se muestra el formulario de conexión. Ingresar servidor, puerto, base de datos, usuario y contraseña. Presionar **Probar conexión y continuar**. Si los datos no son correctos, el sistema informa el error y permite reintentarlo.

## 3. Iniciar sesión
Ingresar usuario y contraseña. En una base recién creada, el usuario inicial es `admin` y la contraseña `Club2026!`. Es una credencial de demostración; cambiarla antes de un uso real.

## 4. Registrar persona
En el menú seleccionar **Alta de persona / socio**. Completar nombre, apellido, tipo y número de documento, teléfono y correo. Elegir SOCIO o NO_SOCIO y marcar apto físico vigente y ficha personal completa. Guardar. El documento no puede repetirse. Si se registra un socio, el sistema también crea su registro de socio y carnet.

## 5. Registrar pago
Seleccionar **Cobro de cuota / pago diario**. Buscar a la persona por documento, elegir MENSUAL o DIARIA, revisar el importe y presionar **Registrar pago**. El sistema informa el vencimiento.

## 6. Consultar vencimientos
Seleccionar **Consultar vencimientos**. La grilla muestra los socios cuya última cuota tiene vencimiento en la fecha actual. Usar **Actualizar** para volver a consultar.

## 7. Salir
Cerrar la ventana principal mediante **Salir**.
