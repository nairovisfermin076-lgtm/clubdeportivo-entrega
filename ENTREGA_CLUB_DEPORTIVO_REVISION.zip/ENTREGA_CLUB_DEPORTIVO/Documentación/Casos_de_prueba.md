# Casos de prueba propuestos — Club Deportivo

Completar fecha, responsable, resultado real, observaciones y evidencia. No marcar aprobado sin ejecutar la prueba.

| ID | Prueba | Resultado esperado |
|---|---|---|
| CP01 | Conexión MySQL correcta | Valida conexión y abre Login |
| CP02 | Contraseña MySQL incorrecta | Informa error y permite reintentar |
| CP03 | Login válido admin / Club2026! | Abre el menú |
| CP04 | Login inválido | Rechaza acceso |
| CP05 | Alta con campos vacíos | Informa validación y no guarda |
| CP06 | Alta sin apto físico o ficha | Rechaza el alta |
| CP07 | Documento duplicado | Rechaza el alta |
| CP08 | Alta de socio | Guarda persona, socio y carnet |
| CP09 | Alta de no socio | Guarda persona sin socio/carnet |
| CP10 | Buscar documento inexistente | Informa que no existe |
| CP11 | Registrar pago diario | Guarda vencimiento del día |
| CP12 | Registrar pago mensual | Calcula inicio y vencimiento según regla documentada |
| CP13 | Consultar vencimientos | Muestra socios cuya última cuota vence hoy |
| CP14 | MySQL apagado o inaccesible | Informa error de conexión |
| CP15 | Ejecutar carpeta Release en otra PC | Inicia y conecta con los datos ingresados |
